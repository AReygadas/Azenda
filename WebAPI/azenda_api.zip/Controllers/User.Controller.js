const express = require("express");
const router = express.Router();    

const UserServices = require('./../Services/UserServices');
const service = new UserServices();


/**
 * @swagger
 * /api/v1/user:
 *   get:
 *     summary: Get User
 *     responses:
 *       200:
 *         description: A list of users
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/Models/User'
 */
router.get('/',(req, res)=>{
    const user = service.getUser();
    res.json(user);
});

module.exports = router;