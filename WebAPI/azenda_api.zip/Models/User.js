const userSchema = {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true, // Ensures unique email addresses
    },
    age: {
      type: Number,
    },
  };
  
module.exports = userSchema;