class PropertyService{
    constructor(){

    }
    getAllProperties(){
        return Ok('Ok');
    }
}

module.exports = PropertyService;

