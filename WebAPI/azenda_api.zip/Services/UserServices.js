class UserServices{
    constructor(){

    }

    getUser(){
        return('Ok');
    }

}

module.exports = UserServices;